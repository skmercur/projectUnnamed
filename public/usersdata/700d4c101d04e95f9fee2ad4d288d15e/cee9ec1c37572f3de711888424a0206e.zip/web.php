<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/test',function(){
  return view('test',['name' => 'sofiane']);
});
Route::get('/respage',function(){
  return view('respage');
});
Route::get('/simpleform',function(){
  return view('simpleform');
});

Route::get('/create','usercreatecontroller@index');
Route::post('/submit','usercreatecontroller@store');
Route::get('/update',function(){
  return view('update');
});
Route::post('/update','usercreatecontroller@update');
Route::get('/submit','usercreatecontroller@index');
Route::get('/userfileupload','UploadFileController@index');
Route::post('/userfileupload','UploadFileController@showUploadFile');

Route::post('/respage','UserControllerForForm@show');
Route::resource('posts','dbformdata');
Auth::routes();
Route::get('{slug}', [
    'uses' => 'PageController@getPage'
])->where('slug', '([A-Za-z0-9\-\/]+)');


Route::get('/home', 'HomeController@index')->name('home');
