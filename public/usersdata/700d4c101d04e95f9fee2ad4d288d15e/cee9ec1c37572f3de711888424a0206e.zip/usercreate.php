<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class usercreate extends Model
{
 protected $fillable = ['{{csrf_token()}}','name','text'];
}
