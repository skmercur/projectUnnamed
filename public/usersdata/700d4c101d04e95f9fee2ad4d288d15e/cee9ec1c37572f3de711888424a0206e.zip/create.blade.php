
@extends('layouts.app')
@section('content')
<div class="form-data">
<form action="submit" method="post">
  @csrf
<input type="text" name="name"class="text" />
<input type="text" name="text" class="textarea" />
<input type="hidden" name="_token" value="{{csrf_token()}}" />
<input type="submit" name="submit" class="submit"/>

</form>
</div>
@endsection
